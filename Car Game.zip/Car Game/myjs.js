
  m=0;
  var y;
  var x;
  function start()
{
   y=setInterval(run,50);
  
    function run()
    {
       if(m==1200)
       {
           clearInterval(x);
           m=0;
       }
       else
       {
        m+=5;
         x=document.getElementById("img");
        x.style.marginLeft=m+'px';
       }
    }
}
function stop()
{
    clearInterval(x);
}
